import argparse
dic={'workers': 2, 'batch_size': 96, 'learning_rate': 0.025, 'learning_rate_min': 0.0, 'momentum': 0.9, 'weight_decay': 0.0003, 'report_freq': 50, 'epochs': 25, 'init_channels': 16, 'layers': 5, 'cutout': False, 'cutout_length': 16, 'drop_path_prob': 0.3, 'save': '/tmp/checkpoints/', 'seed': 2, 'grad_clip': 5, 'train_portion': 0.5, 'arch_learning_rate': 0.0006, 'arch_weight_decay': 0.001, 'tmp_data_dir': '/tmp/pycharm_project_942/', 'note': 'try', 'dropout_rate': [], 'add_width': ['0'], 'add_layers': ['0'], 'cifar100': False}
args=argparse.Namespace(**dic)
print(args)