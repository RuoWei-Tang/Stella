import torch
print(torch.__file__)