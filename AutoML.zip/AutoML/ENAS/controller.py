import tensorflow as tf
from AutoML.ENAS.utils import *
from AutoML.ENAS.networks import*
from tensorflow.keras.layers import (
    AveragePooling2D,
    BatchNormalization,
    Conv2D,
    Dense,
    Dropout,
    GlobalAveragePooling2D,
    MaxPool2D,
    ReLU,
    SeparableConv2D,
)



class Controller:
    def __init__(self,
                 network,
                 lstm_size=64,
                 entropy_reduction = 'sum',
                 skip_target=0.4,
                 temperature=None,
                 tanh_constant=1.5,
                 sample_skip=True,
                 pre_skip=[]):
        print("in controller init:",time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
        self.network=network
        self.lstm_size=lstm_size
        assert entropy_reduction in ['sum', 'mean'], 'Entropy reduction must be one of sum and mean.'
        self.entropy_reduction=tf.reduce_sum if entropy_reduction == 'sum' else tf.reduce_mean
        self.sample_log_prob=0
        self.sample_entropy=0
        self.skip_target=skip_target
        self.skip_targets = tf.constant([1.0 - skip_target, skip_target])
        self.sample_skip_penalty = 0
        self.temperature=temperature
        self.tanh_constant=tanh_constant
        self.num_nodes = self.network.num_nodes
        self.sample_skip=sample_skip
        self.pre_skip=pre_skip
        
        
        
        # network.set_node([1,2,3])
        self.max_layer_choice=[]
        for node_id in range(self.num_nodes):
            self.max_layer_choice.append(network.node_space_len[node_id])
        print("self.max_layer_choice:",self.max_layer_choice)
        
        self.g_emb = tf.random.normal((1, 1, lstm_size)) * 0.1
        # self.g_emb=tf.keras.layers.Embedding((1,1,lstm_size))
        self.lstm = tf.keras.layers.LSTM(lstm_size,time_major=True,
                                    return_sequences=True)
        self.soft = []
        for node_id in range(self.num_nodes):    
            self.soft.append(Dense(self.max_layer_choice[node_id], use_bias=False))
        # print("self.soft:",self.soft)
        self.cross_entropy_loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
        
        self.embedding = []
        for node_id in range(self.num_nodes): 
            self.embedding.append(tf.keras.layers.Embedding(self.max_layer_choice[node_id], lstm_size))
        self.attn_anchor = Dense(lstm_size, use_bias=False)
        self.attn_query = Dense(lstm_size, use_bias=False)
        self.v_attn = Dense(1, use_bias=False)
        self._inputs = self.g_emb
        if sample_skip==False:
            for node_id in range(self.num_nodes):
                self.network.set_skip(node_id,pre_skip[node_id])
        
    def sampler(self):
        # print("in sampler")
        arc_seq=[]
        anchors = []
        anchors_w_1 = []
        w=[]
        for node_id in range(self.num_nodes):
            
            # print('*'*30,node_id,'*'*30)
            # print("in sampler")
            # print("_input:",self._inputs)
            logit=self.lstm(self._inputs)
            
            # print("lstm result:",logit)
            logit=self.soft[node_id](logit)
            
            # print("logit after soft:",logit)
            logit=tf.nn.softmax(logit, axis=-1)
            # logit=tf.squeeze(logit)
            logit=logit[-1]
            # print("logit after softmax:",logit)
            softmax_logit = tf.math.log(logit)
            # print("softmax_logit:",softmax_logit)
            branch_id = tf.reshape(tf.random.categorical(softmax_logit, num_samples=1), [1])
            # print("branch_id:",branch_id)
            self.network.set_branch_id(node_id,branch_id)
            arc_seq.append(branch_id)

            # print("-"*80)
            log_prob = self.cross_entropy_loss(branch_id, logit)
            # print("log_prob:",log_prob)
            self.sample_log_prob += self.entropy_reduction(log_prob)
            # print("sample_log_prob:",self.sample_log_prob)
            entropy = log_prob * tf.math.exp(-log_prob)
            # print("entropy:",entropy)
            self.sample_entropy += self.entropy_reduction(entropy)
            # print("sample_entropy:",self.sample_entropy)
            # print("embedding:",self.embedding(branch_id))
            self._inputs = tf.reshape(self.embedding[node_id](branch_id), [1, 1, -1])
            # print('self.embedding:',self.embedding[node_id](branch_id))
            # print("_inputs:",_inputs)
            next_h=self.lstm(self._inputs)
            if node_id>0 and self.sample_skip==True:
                query = tf.concat(anchors_w_1, axis=0)
                # print("query1:",query)
                query = tf.tanh(query + self.attn_query(next_h[-1]))
                # print("query2:",query)
                query = self.v_attn(query)
                
                # print("query3:",query)
                logit = tf.concat([-query, query], axis=1)
                # print("logit:",logit)
                softmax_logit = tf.math.log(tf.nn.softmax(logit, axis=-1))
                # print("softmax_logit:",softmax_logit)
                skip = tf.reshape(tf.random.categorical(softmax_logit, num_samples=1), [-1])
                arc_seq.append(skip)
                # print("skip:",skip)
                self.network.set_skip(node_id,skip)
                skip_prob = tf.math.sigmoid(logit)
                kl = tf.reduce_sum(skip_prob * tf.math.log(skip_prob / self.skip_targets))
                # print("kl:",kl)
                self.sample_skip_penalty += kl
                log_prob = self.cross_entropy_loss(skip, logit)

                skip = tf.cast(skip, tf.float32)
                inputs = tf.tensordot(skip, tf.concat(anchors, 0), 1) / (1. + tf.reduce_sum(skip))
                # print("anchors:",anchors)
                # print("tf.concat(anchors, 0):",tf.concat(anchors, 0))
                # print("tf.tensordot(skip, tf.concat(anchors, 0), 1):",tf.tensordot(skip, tf.concat(anchors, 0), 1))
                # print("(1. + tf.reduce_sum(skip)):",(1. + tf.reduce_sum(skip)))
                self._inputs = tf.reshape(inputs, [1, 1, -1])
                # print("_input:",self._inputs)
            else:
                if node_id>0:
                    arc_seq.append(self.pre_skip[node_id])
                self._inputs = self.g_emb
            anchors.append(next_h[-1])
            # print("anchors:",anchors)
            anchors_w_1.append(self.attn_anchor(next_h[-1]))
            
            
        # print("in controller self.network.sample_mat:",self.network.sample_mat)
        w.extend(self.lstm.weights)        
        
        
        for node_id in range(self.num_nodes):
            w.extend(self.soft[node_id].weights)
        if self.sample_skip:
            w.extend(self.v_attn.weights)
            w.extend(self.attn_query.weights)
            w.extend(self.attn_anchor.weights)
            for node_id in range(self.num_nodes):
                w.extend(self.embedding[node_id].weights)
        # w.extend(self.g_emb)
        self.w_list=w
        
        arc_seq = tf.concat(arc_seq, axis=0)
        self.network.set_sample_list(arc_seq)
        # print("arc_seq:",arc_seq)
        self.sample_log_prob += self.entropy_reduction(log_prob)
        entropy = log_prob * tf.exp(-log_prob)
        self.sample_entropy += self.entropy_reduction(entropy)
        
        # print("weights of lstm:",w)