import time

from AutoML.ENAS.nodes import get_node_space,build_stem
from tensorflow.keras.layers import BatchNormalization
import tensorflow as tf

from tensorflow.keras import layers, Model
import numpy as np
from tensorflow.keras.layers import (
    AveragePooling2D,
    BatchNormalization,
    Conv2D,
    Dense,
    Dropout,
    GlobalAveragePooling2D,
    MaxPool2D,
    ReLU,
    SeparableConv2D,
    Activation,
    MaxPooling2D,
    Flatten,
)


class FactorizedReduce(Model):
    def __init__(self, filters):
        super().__init__()
        self.conv1 = Conv2D(filters // 2, kernel_size=1, strides=2, use_bias=False)
        self.conv2 = Conv2D(filters // 2, kernel_size=1, strides=2, use_bias=False)
        self.bn = BatchNormalization(trainable=False)

    def call(self, x):
        out1 = self.conv1(x)
        out2 = self.conv2(x[:, 1:, 1:, :])
        out = tf.concat([out1, out2], axis=3)
        out = self.bn(out)
        return out

class Node:
    def __init__(self,
                 node_id,
                 node_name_space=[],
                 mini_enas=True):
        print("in Node init:",time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
        # print("node:",node_space)
        self.node_space=get_node_space(node_name_space[node_id],mini_enas=True)
        # print("node_space in node:",node_space[0])
        self.node_space_len=len(self.node_space)
        self.node_id=node_id
        self.weights={}
        self.branch_id=-1
        self.skip_list=[]
        self.batch_norm = BatchNormalization(trainable=False)
    
    # def set_choice():
    #     print("in set choice")

    def get_node(self,):

        node=self.node_space[self.branch_id[0]]
        return node

    def __call__(self,pre_output,input):
        # print("---------in node ",self.node_id,"calling------------")
        # print("branch ",self.branch_id[0]," is choosen")
        inp=input
        # inp=pre_output[-mini_enas1]

        # if self.node_id>0:        
        #     for rank in range(len(self.skip_list)):
        #         if self.skip_list[rank]==mini_enas1:
        #             inp+=pre_output[rank]
        #         else:
        #             continue
        # inp=tf.cast(inp,tf.float32)
        # print("input shape:",inp.shape)
        out=self.node_space[self.branch_id[0]](inp)
        w=[]
        # print("@@@@@node ",self.node_id," weights:",self.node_space[self.branch_id[0]].weights)
        for layer in self.node_space[self.branch_id[0]].layers:
            # print(layer,"call weight:",layer.trainable)
            if layer.trainable:
                w.extend(layer.weights)
        
        next_inp=out
        # next_inp=self.batch_norm(next_inp)
        if self.node_id>0:
            # print("skio_list:",self.skip_list)
            for rank in range(len(self.skip_list)):
                if self.skip_list[rank]==1:
                    # print("shape_next_inp:",next_inp.shape)
                    # print("shape_pre_out:",pre_output[rank].shape)
                    next_inp+=pre_output[rank]
                else:
                    continue
        out=self.batch_norm(out)
        # print("node:",self.node_id,"  output shape:",out.shape)
        return out,next_inp,w
        
class Network:
    def __init__(self,
                 
                 filters=36,
                 num_classes=10, 
                 dropout_rate=0.0,
                 num_nodes=2,
                 node_name_space=[],
                sample_skip=True,
                pre_skip=[],
                mini_enas=True,
                input_shape=(32,32,3)):
        # print("#####in network init:",time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
        self.num_nodes = num_nodes
        self.nodes=[]
        self.node_name_sapce=node_name_space
        self.sample_list=[]
        # self.sample_mat=np.random.randint(-1,0,(num_nodes,num_nodes))
        self.sample_skip=sample_skip
        self.pre_skip=pre_skip
        # print("node_space in network:",node_space[0])
        # self.node_space_len=len(self.node_name_sapce)
        self.node_space_len=[]
        self.mini_enas=mini_enas
        self.input_shape=input_shape
        for node_id in range(self.num_nodes):
            # print("node_id:",self.num_nodes)
            self.node_space_len.append(len(self.node_name_sapce[node_id]))
        print("self.node_space_len:",self.node_space_len)    
        
        for i in range(self.num_nodes):
            # node=Node(node_id=i,node_name_space=self.node_name_sapce)
            node=Node(node_id=i,node_name_space=self.node_name_sapce,mini_enas=mini_enas)
            self.nodes.append(node)
        
        # print("11111self.sample_mat:",self.sample_mat)
        if sample_skip==False:
            print("in network skip")
            for node_id in range(self.num_nodes):
                if node_id>0:
                 self.set_skip(node_id=node_id,arc=self.pre_skip[node_id])
        # print("22222self.sample_mat:",self.sample_mat)
        
        
        self.stem = build_stem(filters)
        pool_num = 2
        if num_nodes// (pool_num + 1)>1:
            self.pool_distance = num_nodes// (pool_num + 1)
        else:
            self.pool_distance = num_nodes// (pool_num )
        
        print("filter:",filters)
        self.pool_layers = [FactorizedReduce(filters) for _ in range(pool_num)]
        
        self.gap = GlobalAveragePooling2D()
        self.dropout = Dropout(dropout_rate)
        self.dense = Dense(num_classes)
        
    def set_branch_id(self,node_id,arc):
        
        # print("in set_branch_id node=",node_id)
        self.nodes[node_id].branch_id=arc
        # self.sample_mat[node_id][0]=arc
        # print("branch_id:",self.nodes[node_id].branch_id)
        # print("sample_list:",self.sample_list)
        # print("sample_mat:",self.sample_mat)
    def set_skip(self,node_id,arc):
        
        # print("in set_skip node=",node_id)   
        self.nodes[node_id].skip_list=arc
        # self.sample_mat[node_id][1:node_id+1]=arc
        # print("sample_list:",self.nodes[node_id].skip_list)
    
    def set_sample_list(self,arc):
        # print("in set_sample_list")
        self.sample_list=arc
        # print("sample_list:",self.sample_list)
    
    def set_from_list(self,arc):
        # print("in set_from_list")
        start=0
        for node_id in range(self.num_nodes):
            branch_id = tf.reshape(arc[start], [1])
            self.set_branch_id(node_id,branch_id)
            start+=1
            skip = tf.reshape(arc[start:start+node_id], [-1])
            self.set_skip(node_id,skip)
            start+=node_id
            
    def get_model(self):
        node_choice=[]
        output_list=[]
        for i in range(self.num_nodes):
            node_choice.append(self.nodes[i].get_node())
        # inputs = layers.Input(shape=(32,32,3))
        inputs = layers.Input(shape=self.input_shape)
        x=self.stem(inputs)
        # print("mat:",self.sample_mat)
        for i in range(self.num_nodes):
            if i > 0 and i % self.pool_distance == 0:
                pool = self.pool_layers[i // self.pool_distance - 1]
                output_list = [pool(tensor) for tensor in output_list]
                x=pool(x)
            x = node_choice[i](x)
            output_list.append(x)
            for j in range(i):
                # if self.sample_list[((i*(i+1))/2)+1+j]==1:
                if self.nodes[i].skip_list[j]==1:
                #     pass
                # if self.sample_mat[i][j+1]==1:
                    x = layers.add([output_list[j],x])
                    # x = node_choice[i](layers[j])
                # print("in j",i,":",j)
                # pass

        x=self.gap(x)

        x = self.dropout(x)
        # softmax

        x = self.dense(x)
        net_name=''
        if self.mini_enas:
            net_name='MiniEnasNet'
        else:
            net_name='EnasNet'


        model = Model(inputs, x, name=net_name)
        return model



    def __call__(self,x):
        inp=x
        # print("mini_enas1-inp shape:",inp.shape)
        # model=self.get_model()
        # # logits = model(inp)
        # # self.w_list = model.trainable_weights
        #
        #
        # print("summary!")
        # model.summary()
        # print(model.summary())
        # print("**********input_shape:",x.shape)
        # *********input_shape: (64, 32, 32, 3)

        # print("model variable:",model.trainable_weights)

####################################################################################
        self.w_list=[]
        pre_output=[]
        output = self.stem(inp)
        for layer in self.stem.layers:
            if layer.trainable:
                self.w_list.extend(layer.weights)
        # self.w_list.extend(self.stem.weights)
        # print("@@@@@stem weights:",self.stem.weights)
        pre_output.append(output)
        inp=output
        i=0
        for node in self.nodes:
            if i > 0 and i % self.pool_distance == 0:
                # print(i,self.pool_distance)
                pool = self.pool_layers[i // self.pool_distance - 1]
                pre_output = [pool(tensor) for tensor in pre_output]
                inp=pool(inp)
                # print("test:",pre_output[0].shape)
                # print("pool weights:",pool.weights)
                for layer in pool.layers:
                    if layer.trainable:
                        self.w_list.extend(layer.weights)
                    # self.w_list.extend(pool.weights)
                # cur = pre_output[-mini_enas1]
            output,next_inp,w=node(pre_output,inp)
            # print("test****",i,"******",output)
            pre_output.append(output)
            # inp=output
            inp=next_inp
            self.w_list.extend(w)
            i+=1

        cur = self.gap(output)
        # print("gap weights:",self.gap.weights)
        cur = self.dropout(cur)
        # print("gap weights:",self.dropout.weights)
        logits = self.dense(cur)
        # print("gap weights:",self.dense.weights)
        self.w_list.extend(self.dense.weights)
        return logits