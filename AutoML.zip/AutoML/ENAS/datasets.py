import time

import tensorflow as tf

def get_cifar10():
    (x_train, y_train), (x_valid, y_valid) = tf.keras.datasets.cifar10.load_data()
    x_train, x_valid = x_train / 255.0, x_valid / 255.0
    train_set = (x_train, y_train)
    valid_set = (x_valid, y_valid)
    return train_set, valid_set


# import tensorflow as tf
from AutoML.ENAS.data_loaders import cifar10,cifar100,fashion_mnist

from AutoML.ENAS.read_minio import load_data_minio
from AutoML.ENAS.setting import*
import os
def get_dataset(name):
    current_work_dir = os.path.abspath(os.path.dirname(__file__)) 
    # rootPath = current_work_dir[:current_work_dir.find(args.project_name)+len(args.project_name)]
    # rootPath=rootPath+'/'
    print('current_work_dir:',current_work_dir)
    load_data_minio(bucket,name)
    if name=='mnist':
        print("ppp",current_work_dir+'/data/mnist.npz.zip_dir/mnist.npz')
        # (x_train, y_train), (x_valid, y_valid) = tf.keras.datasets.mnist.load_data(current_work_dir+'/data/mnist.npz.zip_dir/mnist.npz')
        (x_train, y_train), (x_valid, y_valid) = tf.keras.datasets.mnist.load_data(path=current_work_dir+'/data/mnist.npz')
    elif name=='cifar10':
        # (x_train, y_train), (x_valid, y_valid) = tf.keras.datasets.cifar10.load_data()
        (x_train, y_train), (x_valid, y_valid) = cifar10.load_data()
    elif name=='cifar100':
        # (x_train, y_train), (x_valid, y_valid) = tf.keras.datasets.cifar100.load_data(current_work_dir+'data/cifar-100-python.tar.gz')
        (x_train, y_train), (x_valid, y_valid) = cifar100.load_data()
    elif name=='fashion_mnist':
        # (x_train, y_train), (x_valid, y_valid) = tf.keras.datasets.fashion_mnist.load_data()
        (x_train, y_train), (x_valid, y_valid) = fashion_mnist.load_data()
    
    print(len(x_train.shape))
    if len(x_train.shape)==3:
        num_train=x_train.shape[0]
        size_train=x_train.shape[1]
        num_vaild=x_valid.shape[0]
        print(num_train,size_train)
        x_train = x_train.reshape((num_train, size_train, size_train, 1))
        x_valid = x_valid.reshape((num_vaild, size_train, size_train, 1))
    
    print("test1:",time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())),flush=True)
    x_train, x_valid = x_train / 255.0, x_valid / 255.0
    print("test1:",time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
    train_set = (x_train, y_train)
    valid_set = (x_valid, y_valid)

    print("datasets finished:",time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
    return train_set, valid_set