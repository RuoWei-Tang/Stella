import AutoML.ENAS.datasets as datasets
from AutoML.ENAS.trainer import *
import tensorflow as tf
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)


class ENASManager():
    def __init__(self,get_data=True):
        self.dataset='cifar10'
        self.reward_function=accuracy
        self.metrics=accuracy_metrics
        self.optimizer = SGD(learning_rate=0.005, momentum=0.9)
        self.num_epochs=3
        self.batch_size=64
        self.child_steps=40
        self.controller_steps=10
        self.log_frequency=10
        self.entropy_weight=0.0001
        self.baseline_decay=0.999
        self.skip_weight=0.8
        self.controller_lr=0.00035
        self.test_per_epoch=1
        self.save_every=5
        self.num_nodes=12
        self.filters=36
        self.num_classes=10
        self.dropout_rate=0.0
        self.lstm_size=64
        self.entropy_reduction = 'sum'
        self.skip_target=0.4
        self.temperature=None
        self.tanh_constant=1.5
        self.sample_skip=True
        self.pre_skip=None
        self.node_name_space=[]
        self.sample_skip=True
        self.pre_skip=[]
        self.mini_enas=True
        self.expansion=3
        self.get_data=get_data
        self.local_middle_save_path=''
        self.train_instance_id=None
        for i in range(self.num_nodes):
            self.node_name_space.append([{'type':'conv','filters':self.filters,'kernel_size':3},
                                {'type':'conv','filters':self.filters,'kernel_size':5},
                                {'type':'conv','filters':self.filters,'kernel_size':7},
                                {'type':'avgpool','filters':self.filters},
                                {'type':'maxpool','filters':self.filters}],)
        # print("len(self.node_name_space):",self.node_name_space)
            
       
    def set_dataset_name(self,dataset_name):
        self.dataset=dataset_name
        if dataset_name=='cifar100':
            self.num_classes=100

        self.dataset_train, self.dataset_valid = datasets.get_dataset(self.dataset)

    def set_dataset(self,dataset_train,dataset_valid):
        self.dataset_train=dataset_train
        self.dataset_valid = dataset_valid
        
    
    def set_num_nodes(self,num):
        self.num_nodes=num
        self.node_name_space=[]
        for i in range(self.num_nodes):
            self.node_name_space.append([{'type':'conv','filters':self.filters,'kernel_size':3},
                                {'type':'conv','filters':self.filters,'kernel_size':5},
                                {'type':'conv','filters':self.filters,'kernel_size':7},
                                {'type':'avgpool','filters':self.filters},
                                {'type':'maxpool','filters':self.filters}],)
        
    
    def set_node_name_space(self,name_space):
        self.node_name_space=name_space
    
    def set_num_filters(self,num):
        self.filters=num
        
    def set_num_classes(self,num):
        self.num_classes=num
    
    def set_pre_skip(self,pre_skip_list):
        self.sample_skip=False
        self.pre_skip=pre_skip_list

    def set_enas_type(self,mini_enas):
        if mini_enas:
            self.mini_enas=True
        else:
            self.mini_enas=False

    def set_local_middle_save_path(self,local_middle_save_path):
        self.local_middle_save_path=local_middle_save_path
    
    def set_train_instance_logger(self,train_instance_logger):
        self.train_instance_logger=train_instance_logger
    
    def set_train_instance_id(self,train_instance_id):
        self.train_instance_id=train_instance_id
        
    def set_trainer(self):
        # if self.get_data:
        #     self.set_dataset_name(self.dataset)
        self.trainer=ENASTrainer(self.dataset_train, 
                            self.dataset_valid,
                            node_name_space=self.node_name_space,
                            reward_function=self.reward_function,
                            metrics=self.metrics,
                            optimizer = self.optimizer,
                            num_epochs=self.num_epochs,
                            batch_size=self.batch_size,
                            child_steps=self.child_steps,
                            controller_steps=self.controller_steps,
                            log_frequency=self.log_frequency,
                            entropy_weight=self.entropy_weight,
                            baseline_decay=self.baseline_decay,
                            skip_weight=self.skip_weight,
                            controller_lr=self.controller_lr,
                            test_per_epoch=self.test_per_epoch,
                            save_every=self.save_every,
                            num_nodes=self.num_nodes,
                            filters=self.filters,
                            num_classes=self.num_classes, 
                            dropout_rate=self.dropout_rate,
                            lstm_size=self.lstm_size,
                            entropy_reduction = self.entropy_reduction,
                            skip_target=self.skip_target,
                            temperature=self.temperature,
                            tanh_constant=self.tanh_constant,
                            sample_skip=self.sample_skip,
                            pre_skip=self.pre_skip,
                            mini_enas=self.mini_enas,
                            expansion=self.expansion,
                            local_middle_save_path=self.local_middle_save_path,
                            train_instance_logger=self.train_instance_logger,
                            train_instance_id=self.train_instance_id)
    
    def get_trainer(self):
        return self.trainer
        
    def start_train(self):
        # pid = os.getpid()
        # print("pid:",pid)
        self.set_trainer()
        save_model=self.trainer.fit()
        print("finished!!!")
        print(save_model)
# manager=ENASManager()
# manager.set_num_nodes(4)
# manager.set_trainer()