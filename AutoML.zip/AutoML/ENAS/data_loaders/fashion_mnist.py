from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import gzip
import os

import numpy as np

from tensorflow.python.keras.utils.data_utils import get_file
from tensorflow.python.util.tf_export import keras_export
from AutoML.ENAS.setting import *

@keras_export('keras.datasets.fashion_mnist.load_data')
def load_data():
    current_work_dir = os.path.abspath(os.path.dirname(__file__)) 
    # print('!',sys.argv[0])
    rootPath = current_work_dir[:current_work_dir.find(project_name)+len(project_name)]
    # rootPath=rootPath+'/'
    print('root:',rootPath)
    path=rootPath+'/data/fashion-mnist.zip_dir/fashion-mnist/'
    # dirname = os.path.join(rootPath, '/data/fashion-mnist.zip_dir/fashion-mnist')
    print("dirname:",path)
    # base = 'https://storage.googleapis.com/tensorflow/tf-keras-datasets/'
    files = [
        'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
        't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
    ]
    
    paths = []
    
    for fname in files:
        paths.append(path + fname)
    print("paths:",paths)
    with gzip.open(paths[0], 'rb') as lbpath:
        y_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        x_train = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(y_train), 28, 28)

    with gzip.open(paths[2], 'rb') as lbpath:
        y_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        x_test = np.frombuffer(
            imgpath.read(), np.uint8, offset=16).reshape(len(y_test), 28, 28)

    return (x_train, y_train), (x_test, y_test)