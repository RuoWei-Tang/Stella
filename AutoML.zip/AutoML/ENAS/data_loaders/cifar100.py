import os

import numpy as np

from tensorflow.python.keras import backend as K
from tensorflow.python.keras.datasets.cifar import load_batch
from tensorflow.python.keras.utils.data_utils import get_file
from tensorflow.python.util.tf_export import keras_export
from AutoML.ENAS.setting import *

# @keras_export('keras.datasets.cifar100.load_data')
def load_data(label_mode='fine'):

    if label_mode not in ['fine', 'coarse']:
        raise ValueError('`label_mode` must be one of `"fine"`, `"coarse"`.')



#   dirname = 'cifar-100-python'
#   origin = 'https://www.cs.toronto.edu/~kriz/cifar-100-python.tar.gz'
#   path = get_file(
#       dirname,
#       origin=origin,
#       untar=True,
#       file_hash=
#       '85cd44d02ba6437773c5bbd22e183051d648de2e7d6b014e1ef29b855ba677a7')


    current_work_dir = os.path.abspath(os.path.dirname(__file__)) 
    # print('!',sys.argv[0])
    rootPath = current_work_dir[:current_work_dir.find(project_name)+len(project_name)]
    # rootPath=rootPath+'/'
    print('root:',rootPath)

    path=rootPath+'/data/cifar100.zip_dir/cifar100'
    
    fpath = os.path.join(path, 'train')
    x_train, y_train = load_batch(fpath, label_key=label_mode + '_labels')

    fpath = os.path.join(path, 'test')
    x_test, y_test = load_batch(fpath, label_key=label_mode + '_labels')

    y_train = np.reshape(y_train, (len(y_train), 1))
    y_test = np.reshape(y_test, (len(y_test), 1))

    if K.image_data_format() == 'channels_last':
        x_train = x_train.transpose(0, 2, 3, 1)
        x_test = x_test.transpose(0, 2, 3, 1)

    return (x_train, y_train), (x_test, y_test)