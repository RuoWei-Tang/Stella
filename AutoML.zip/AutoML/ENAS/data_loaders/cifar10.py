import os

import numpy as np

# from mini_enas import mini_enas1

from tensorflow.python.keras import backend as K
from tensorflow.python.keras.datasets.cifar import load_batch
from tensorflow.python.keras.utils.data_utils import get_file
from tensorflow.python.util.tf_export import keras_export
from AutoML.ENAS.setting import *

def load_data():

    print("in cifar10 loader")
    num_train_samples = 50000
    current_work_dir = os.path.abspath(os.path.dirname(__file__)) 
    # print('!',sys.argv[0])
    rootPath = current_work_dir[:current_work_dir.find(project_name)+len(project_name)]
    # rootPath=rootPath+'/'
    print('root:',rootPath)
    
    path=rootPath+'/data/cifar10.zip_dir/cifar10'
    print('path:',path)
    x_train = np.empty((num_train_samples, 3, 32, 32), dtype='uint8')
    y_train = np.empty((num_train_samples,), dtype='uint8')

    for i in range(1, 6):
        fpath = os.path.join(path, 'data_batch_' + str(i))
        (x_train[(i - 1) * 10000:i * 10000, :, :, :],
        y_train[(i - 1) * 10000:i * 10000]) = load_batch(fpath)

    fpath = os.path.join(path, 'test_batch')
    x_test, y_test = load_batch(fpath)

    y_train = np.reshape(y_train, (len(y_train), 1))
    y_test = np.reshape(y_test, (len(y_test), 1))

    if K.image_data_format() == 'channels_last':
        x_train = x_train.transpose(0, 2, 3, 1)
        x_test = x_test.transpose(0, 2, 3, 1)

    x_test = x_test.astype(x_train.dtype)
    y_test = y_test.astype(y_train.dtype)
    print("cifar10 loader finished")

    return (x_train, y_train), (x_test, y_test)


# dataset_train, dataset_valid=load_data()
# print(dataset_valid[0].shape)