import logging
import tensorflow as tf
from AutoML.ENAS.networks import *
from AutoML.ENAS.controller import *
from tensorflow.keras.optimizers import SGD, Adam
from tensorflow.keras.models import load_model
from AutoML.ENAS.utils import accuracy, fill_zero_grads, accuracy_metrics

from contextlib import redirect_stdout
from AutoML.ENAS.setting import log_path
from logger.logger import logger
# logging.basicConfig(filename=(log_path+"/logfile.log"), level=logging.INFO, filemode='w'
#                     , format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# logger = logging.getLogger(__name__)
from tensorflow.keras.losses import Reduction, SparseCategoricalCrossentropy
from trainFlow.trainInfo.onTraining import *
# from AutoML.ENAS.setting import save_model_path,log_path

class ENASTrainer:
    def __init__(self,
                 dataset_train,
                 dataset_valid,
                 node_name_space=[],
                 reward_function=accuracy,
                 metrics=accuracy_metrics,
                 optimizer=SGD(learning_rate=0.05, momentum=0.9),
                 num_epochs=5,
                 batch_size=64,
                 child_steps=20,
                 controller_steps=10,
                 #  controller_steps_aggregate=2,
                 log_frequency=5,
                 entropy_weight=0.0001,
                 baseline_decay=0.999,
                 skip_weight=0.8,
                 controller_lr=0.0005,
                 test_per_epoch=1,
                 save_every=5,
                 num_nodes=2,
                 filters=36,
                 num_classes=10,
                 dropout_rate=0.0,
                 lstm_size=64,
                 entropy_reduction='sum',
                 skip_target=0.4,
                 temperature=None,
                 tanh_constant=1.5,
                 sample_skip=True,
                 pre_skip=[],
                 mini_enas=True,
                 expansion=3,
                 local_middle_save_path='',
                 train_instance_logger=None,
                 train_instance_id=None):
        print("in trainer init:", time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
        if mini_enas:
            print("mini_enas Trainer")
        self.final_model = None
        self.child_steps = child_steps
        self.controller_steps = controller_steps
        # self.controller_steps_aggregate=controller_steps_aggregate
        self.reward_function = reward_function
        self.entropy_weight = entropy_weight
        self.baseline_decay = baseline_decay
        self.skip_weight = skip_weight
        self.controller_lr = controller_lr
        self.baseline = 0.0
        self.test_per_epoch = test_per_epoch
        self.metrics = metrics
        self.save_every = save_every
        self.filters=filters
        self.num_nodes=num_nodes

        val_size=int((tf.data.experimental.cardinality(dataset_train).numpy())*0.9)
        # print("val_size:",val_size)
        dataset_train=dataset_train.map(self.process_ds)
        dataset_valid=dataset_valid.map(self.process_ds)
        print((dataset_train._flat_shapes[0]))


        self.train_set = dataset_train.take(val_size)
        self.valid_set = dataset_train.skip(val_size)
        self.test_set = dataset_valid
        self.local_middle_save_path=local_middle_save_path
        self.save_model_path=self.local_middle_save_path+'/model'
        self.train_instance_logger=train_instance_logger
        self.train_instance_id=train_instance_id

        # x, y = dataset_train
        # print("ok1")
        # split = int(len(x) * 0.9)
        # print("ok2")
        
        # self.train_set = tf.data.Dataset.from_tensor_slices((x[:split], y[:split]))
        # self.valid_set = tf.data.Dataset.from_tensor_slices((x[split:], y[split:]))
        # self.test_set = tf.data.Dataset.from_tensor_slices(dataset_valid)

        self.comp_loss = SparseCategoricalCrossentropy(from_logits=True, reduction=Reduction.NONE)
        self.controller_optim = Adam(learning_rate=self.controller_lr)

        self.save_model = {'accuracy': 0}
        self.num_epochs = num_epochs
        self.batch_size = batch_size
        self.log_frequency = log_frequency
        self.optimizer = optimizer
        self.mini_enas=mini_enas
        self.expansion=expansion
        self.network = Network(num_nodes=num_nodes,
                               filters=filters,
                               num_classes=num_classes,
                               dropout_rate=dropout_rate,
                               node_name_space=node_name_space,
                               sample_skip=sample_skip,
                               pre_skip=pre_skip,
                               mini_enas=mini_enas,
                               input_shape=dataset_train._flat_shapes[0])
        self.controller = Controller(self.network,
                                     lstm_size=lstm_size,
                                     entropy_reduction=entropy_reduction,
                                     skip_target=skip_target,
                                     temperature=temperature,
                                     tanh_constant=tanh_constant,
                                     sample_skip=sample_skip,
                                     pre_skip=pre_skip)

    def train_one_step(self, train_loader):
        
        x, y = next(train_loader)
        x = tf.cast(x, tf.float32)
        y = tf.cast(y, tf.float32)
        

        with tf.GradientTape() as tape:
            logits = self.network(x)
            log_probs = self.comp_loss(y, logits)
            # print("log_probs:",log_probs)
            loss = tf.reduce_mean(log_probs)
            # print("step ",step," loss:",loss)
            # grads = tape.gradient(loss, self.network.w_list)
        grads = tape.gradient(loss, self.network.w_list)  # 使用 model.variables 这一属性直接获得模型中的所有变量
        # print("child grads:",grads)
        grads, _ = tf.clip_by_global_norm(grads, 5.0)
        self.optimizer.apply_gradients(grads_and_vars=zip(grads, self.network.w_list))

    def validate_one_model(self, model, train_steps=500, valid_steps=50):
        train_loader, valid_loader = self.create_train_loader()

        self.network.set_from_list(model['sample_list'])
        for inner_Step in range(train_steps):
            self.train_one_step(train_loader)

        for inner_Step in range(valid_steps):
            x, y = next(valid_loader)
            x = tf.cast(x, tf.float32)
            y = tf.cast(y, tf.float32)
            logits = self.network(x)
            metrics = self.metrics(y, logits)
            loss = self.comp_loss(y, logits)
            loss = tf.reduce_mean(loss).numpy()
            reward = (
                    self.reward_function(y, logits)
                    + self.entropy_weight * self.controller.sample_entropy
            )
            if inner_Step == 0:
                model['reward'] = float(reward)
                model['accuracy'] = metrics['enas_acc']
                model['loss'] = loss
            else:
                model['reward'] = (model['reward'] + float(reward))
                model['accuracy'] = (model['accuracy'] + metrics['enas_acc'])
                model['loss'] = (model['loss'] + loss)

        model['reward'] = model['reward']/valid_steps
        model['accuracy'] = model['accuracy']  /valid_steps
        model['loss'] = model['loss'] / valid_steps

        return model

    def train_one_epoch(self, epoch):
        print("----------in {} epoch training----------".format(epoch))
        train_loader, valid_loader = self.create_train_loader()

        for step in range(1, self.child_steps + 1):
            self.controller.sampler()
            self.train_one_step(train_loader)
            
            

            if self.log_frequency and step % self.log_frequency == 0:
                logger.info(
                    "Model Epoch [%d/%d] Step [%d/%d]  ",
                    epoch + 1,
                    self.num_epochs,
                    step,
                    self.child_steps
                )

        for step in range(1, self.controller_steps + 1):
            # print("#"*30,step,"#"*30)
            with tf.GradientTape() as tape:
                x, y = next(valid_loader)
               
                x = tf.cast(x, tf.float32)
                y = tf.cast(y, tf.float32)
                self.controller.sampler()

                logits = self.network(x)
                # metrics = self.metrics(y, logits)
                reward = (
                        self.reward_function(y, logits)
                        + self.entropy_weight * self.controller.sample_entropy
                )
                # print("reward:",reward)
                self.baseline = self.baseline * self.baseline_decay + reward * (
                        1 - self.baseline_decay
                )
                # print("baseline:",self.baseline)
                loss = self.controller.sample_log_prob * (reward - self.baseline)
                # print("log_prob:",self.controller.sample_log_prob)
                # print("loss:",loss)
                loss += self.skip_weight * self.controller.sample_skip_penalty

                # cur_step = step + (controller_step - mini_enas1) * self.controller_steps_aggregate
                if self.log_frequency and step % self.log_frequency == 0:
                    logger.info(
                        "RL Epoch [%d/%d] Step [%d/%d]  ",
                        epoch + 1,
                        self.num_epochs,
                        step,
                        self.controller_steps,
                    )

            # print("controller loss:",loss)

            grads = tape.gradient(loss, self.controller.w_list)
            grads, _ = tf.clip_by_global_norm(grads, 5.0)
            self.controller_optim.apply_gradients(zip(grads, self.controller.w_list))

            # print("#"*30,"out of for-circle")

    def validate_one_epoch(self, epoch):
        print("*" * 70)
        print("in {} epoch validating".format(epoch))

        test_loader = self.create_validate_loader()
        avg_loss = 0.0
        avg_metrics = 0.0
        count = 0
        flag = False
        model = {'reward': 0}
        # model2 = {'acc': 0}
        if epoch % self.save_every == 0:
            flag = True
        for arc_id in range(self.test_per_epoch):
            for x, y in test_loader:
                x = tf.cast(x, tf.float32)
                y = tf.cast(y, tf.float32)
                # print("x_size:",x.shape)
                self.controller.sampler()



                logits = self.network(x)
                # print("logits:",logits)
                if isinstance(logits, tuple):
                    logits, _ = logits
                metrics = self.metrics(y, logits)
                loss = self.comp_loss(y, logits)
                # print("loss1:",loss)
                loss = tf.reduce_mean(loss).numpy()
                # print("loss2:",loss)
                if flag:
                    reward = (
                            self.reward_function(y, logits)
                            + self.entropy_weight * self.controller.sample_entropy
                    )
                    if model['reward'] < reward:
                        model['reward'] = float(reward)
                        model['accuracy'] = metrics['enas_acc']
                        model['loss'] = loss
                        model['sample_list'] = self.network.sample_list
                        # model['sample_mat'] = self.network.sample_mat

                avg_loss = (avg_loss + loss)
                avg_metrics = (avg_metrics + metrics['enas_acc'])
                count += 1
                # metrics["loss"] = tf.reduce_mean(loss).numpy()
                # meters.update(metrics)
            print("valid acc:", avg_metrics / count)
            print("valid loss:", avg_loss / count)
            # print("count:",count)
            # print("loss:",avg_loss)

            logger.info(
                "Test Epoch [%d/%d] Arc [%d/%d] acc %s  loss %s  ",
                epoch + 1,
                self.num_epochs,
                arc_id + 1,
                self.test_per_epoch,
                avg_metrics / count,
                avg_loss / count
                # meters.summary(),
            )
            if flag:
                logger.info(
                    "Valid model in Epoch %d : reward=%s loss=%s accuracy=%s sample_list=%s ",
                    epoch + 1,
                    model['reward'],
                    model['loss'],
                    model['accuracy'],
                    model['sample_list'].numpy(),
                    # model['sample_mat']
                )
                if True:
                # if epoch > self.num_epochs * 0.7:
                    

                    logger.info(
                        "Save model in Epoch %d : reward=%s loss=%s accuracy=%s sample_list=%s ",
                        epoch + 1,
                        model['reward'],
                        model['loss'],
                        model['accuracy'],
                        model['sample_list'].numpy(),
                        # model['sample_mat']
                    )

                    if self.save_model['accuracy'] < model['accuracy']:
                        print("save_model!",self.save_model_path)
                        # print("save model!",model['sample_mat'])
                        self.save_model['reward'] = model['reward']
                        self.save_model['accuracy'] = model['accuracy']
                        self.save_model['loss'] = model['loss']
                        self.save_model['sample_list'] = model['sample_list']
                        # self.save_model['sample_mat'] = model['sample_mat']
                        self.network.set_from_list(model['sample_list'])
                        self.temp_model=self.network.get_model()
                        self.temp_model.save(self.save_model_path, save_format='tf')

    def create_train_loader(self):
        
        train_set = self.train_set.batch(self.batch_size).shuffle(1000000).repeat()
        # print(type(train_set))
        test_set = self.valid_set.batch(self.batch_size).shuffle(1000000).repeat()
        return iter(train_set), iter(test_set)

    def create_validate_loader(self):
        return iter(self.test_set.batch(self.batch_size).shuffle(1000000))
    
    def process_ds(self, image, label):    
        new_label = tf.argmax(label)
        return image, new_label

    def get_final_model(self):

        # self.network.set_from_list(self.save_model['sample_list'])
        # self.save_model = self.validate_one_model(model=self.save_model, train_steps=500, valid_steps=50)
        # final_model = self.network.get_model()
        final_model = load_model(self.save_model_path,compile=False)
        return final_model

    def get_mat_from_list(self,sample_list):
        sample_mat=np.random.randint(-1,0,(self.num_nodes,self.num_nodes))
        for i in range(self.num_nodes):
            # self.sample_mat[i][0]=sample_list[((i*(i+1))/2)]
            for j in range(i+1):
                sample_mat[i][j]=sample_list[int((i*(i+1))/2)+j]
        return sample_mat

    def fit(self):

        time_start = time.time()
        start=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        type=''
        if self.mini_enas:
            type='Mini ENAS'
        else:
            type='Normal ENAS'
        self.train_instance_logger.info(
            "Start Fit {} expansion={}  filter={}  epoch={} start_time={} num_nodes={}".format(type,
            self.expansion,
            self.filters,
            self.num_epochs,
            start,
            self.num_nodes)
            
        )
        # logger.info(
        #     "2Start Fit {} expansion={}  filter={}  epoch={} start_time={} num_nodes={}".format(type,
        #     self.expansion,
        #     self.filters,
        #     self.num_epochs,
        #     start,
        #     self.num_nodes)
            
        # )
        logger.info(
            "Start Fit %s expansion=%s  filter=%s  epoch=%s start_time=%s num_nodes=%s",
            type,
            self.expansion,
            self.filters,
            self.num_epochs,
            start,
            self.num_nodes

            # meters.summary(),
        )
        for epoch in range(self.num_epochs):
            # logger.info("Epoch %d Training", epoch + mini_enas1)
            self.train_one_epoch(epoch)
            # logger.info("Epoch %d Validating", epoch + mini_enas1)
            self.validate_one_epoch(epoch)
            
            # print("self.save_model['sample_mat']:", self.save_model['sample_mat'])

        self.final_model = self.get_final_model()
        print("finished!!!")
        self.final_model.summary()
        time_end = time.time()  # 记录结束时间
        time_sum = time_end - time_start  # 计算的时间差为程序的执行时间，单位为秒/s
        print('time_sum:', time_sum/(60*60))
        sample_mat=self.get_mat_from_list(self.save_model['sample_list'])
        self.train_instance_logger.info(
            "Final Model  acc {}  loss {} sample_list={}  sample_mat={} total_time={}(hours) count_params={}".format(self.save_model['accuracy'],
            self.save_model['loss'],
            self.save_model['sample_list'],
            # self.save_model['sample_mat'],
            sample_mat,
            time_sum/(60*60),
            self.final_model.count_params())

            
            
        )
        logger.info(
            "Final Model  acc %s  loss %s sample_list=%s  sample_mat=%s total_time=%s(hours) count_params=%s",

            self.save_model['accuracy'],
            self.save_model['loss'],
            self.save_model['sample_list'],
            # self.save_model['sample_mat'],
            sample_mat,
            time_sum/(60*60),
            self.final_model.count_params()

            # meters.summary(),
        )
        # 这段代码用来将model.summary() 输出保存为文件
        # from tensorflow.python.keras.utils import layer_utils
        # layer_utils.print_summary(self,
        #                       line_length=200,
        #                       positions=[0.30, 0.60, 0.7, 1.0],
        #                       print_fn=self.train_instance_logger.info)
        print("successful print summary")
        with open(self.local_middle_save_path+'/model_summary.txt', 'w') as f:
            with redirect_stdout(f):
                self.final_model.summary(line_length=200, positions=[0.30, 0.60, 0.7, 1.0])

        self.final_model.summary(print_fn=self.train_instance_logger.info)

        # plot_model(self.final_model, to_file='final_model.png', show_shapes=True)

        return self.final_model
