import datasets
# from child import *
from .trainer import *

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)
# dataset_train, dataset_valid = datasets.get_cifar10()
# trainer=ENASTrainer(dataset_train, dataset_valid,num_epochs=3)
# trainer.train_one_epoch(mini_enas1)
# trainer.validate_one_epoch(mini_enas1)

#ok
skip_weight=0.8
controller_lr=0.00035
test_per_epoch=1
save_every=5
num_nodes=4
filters=36
num_classes=10
dropout_rate=0.0
lstm_size=64
entropy_reduction = 'sum'
skip_target=0.4
temperature=None
tanh_constant=1.5
pre_skip=[[],[0],[0,1],[1,0,1]]
node_name_space=[[{'type':'conv','filters':filters,'kernel_size':3},
                    {'type':'conv','filters':filters,'kernel_size':5},
                  {'type':'conv','filters':filters,'kernel_size':7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                    {'type':'avgpool','filters':filters},
                    {'type':'maxpool','filters':filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                    {'type':'avgpool','filters':filters},
                    {'type':'maxpool','filters':filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}
                  ],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                  {'type': 'avgpool', 'filters': filters},
                  {'type': 'maxpool', 'filters': filters}
                  ],
                 [{'type': 'conv', 'filters': filters, 'kernel_size': 3},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 5},
                  {'type': 'conv', 'filters': filters, 'kernel_size': 7},
                    {'type':'avgpool','filters':filters},
                    {'type':'maxpool','filters':filters}],]

# node_name_space=[[{'type':'conv','filters':filters,'kernel_size':3},
#                     {'type':'sepconv','filters':filters,'kernel_size':3},
#                     {'type':'conv','filters':filters,'kernel_size':5},
#                     {'type':'sepconv','filters':filters,'kernel_size':5}],
#                  [{'type':'conv','filters':filters,'kernel_size':3},
#                     {'type':'sepconv','filters':filters,'kernel_size':3},
#                     {'type':'conv','filters':filters,'kernel_size':5},
#                     {'type':'sepconv','filters':filters,'kernel_size':5},],
#                  [{'type':'conv','filters':filters,'kernel_size':3},
#                     {'type':'sepconv','filters':filters,'kernel_size':3},
#                     {'type':'conv','filters':filters,'kernel_size':5},
#                     {'type':'sepconv','filters':filters,'kernel_size':5},],
#                  [{'type':'conv','filters':filters,'kernel_size':3},
#                     {'type':'sepconv','filters':filters,'kernel_size':3},
#                     {'type':'conv','filters':filters,'kernel_size':5},
#                     {'type':'sepconv','filters':filters,'kernel_size':5},
#                     {'type':'avgpool','filters':filters},
#                     {'type':'maxpool','filters':filters}]]


# network=Network(num_nodes=num_nodes,
#                 node_name_space=node_name_space)
# controller=Controller(network,
#                         lstm_size=lstm_size,
#                         entropy_reduction = entropy_reduction,
#                         skip_target=skip_target,
#                         temperature=temperature,
#                         tanh_constant=tanh_constant,
#                         sample_skip=False,
#                         pre_skip=pre_skip)



# controller.sampler()
# print(network.sample_list)
# for node in network.nodes:
#     print("-"*50)
#     print(node.branch_id)
#     print(node.skip_list)

# network.set_from_list(network.sample_list)
# for node in network.nodes:
#     print("#"*50)
#     print(node.branch_id)
#     print(node.skip_list)



# import os
import requests
# Get the pid of the process.
pid = os.getpid()
print("pid:",pid)
# url = 'http://10.10.1.210/api/v1/job/create'
# data = {
#
# 'student_id': '1913188',
# 'password': '123456',
# 'description': '测试enas',
# 'server_ip': '10.10.1.208',
# 'duration': '几天',
# 'pid': pid,
# 'server_user': 'yuchuanyue',
# 'command': 'python',
# 'use_gpu': 1,
# }
# r = requests.post(url, data=data)
# print(r.text)

dataset_train, dataset_valid = datasets.get_dataset('cifar10')
# dataset_train, dataset_valid = datasets.get_dataset('mnist')
# dataset_train, dataset_valid = datasets.get_dataset('cifar100')
# dataset_train, dataset_valid = datasets.get_dataset('mnist')

trainer=ENASTrainer(dataset_train,
                    dataset_valid,
                    node_name_space=node_name_space,
                    reward_function=accuracy,
                    metrics=accuracy_metrics,
                    optimizer = SGD(learning_rate=0.005, momentum=0.9),
                    num_epochs=350,
                    batch_size=64,
                    child_steps=500,
                    controller_steps=100,
                    #  controller_steps_aggregate=2,
                    log_frequency=100,
                    entropy_weight=0.0001,
                    baseline_decay=0.999,
                    skip_weight=0.8,
                    controller_lr=0.00035,
                    test_per_epoch=1,
                    save_every=5,
                    num_nodes=12,
                    filters=filters,
                    num_classes=10,
                    dropout_rate=0.0,
                    lstm_size=64,
                    entropy_reduction = 'sum',
                    skip_target=0.4,
                    temperature=None,
                    tanh_constant=1.5,
                    sample_skip=True,
                    pre_skip=pre_skip,
                    mini_enas=True,
                    expansion=3)



trainer.fit()


# sample_mat=np.random.randint(-1,0,(num_nodes,num_nodes))
# sample_mat[0][0]=0
# sample_mat[1][1]=1
# print(sample_mat)
# mat=sample_mat
# print(mat)
# sample_mat[0][3]=3
# print(sample_mat)
# print(mat)