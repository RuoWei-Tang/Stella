from tensorflow.python.keras.models import Sequential
from tensorflow.keras.layers import (
    AveragePooling2D,
    BatchNormalization,
    Conv2D,
    Dense,
    Dropout,
    GlobalAveragePooling2D,
    MaxPool2D,
    ReLU,
    SeparableConv2D,
)


def build_conv(filters, kernel_size, name=None):
    return Sequential([
        Conv2D(filters, kernel_size=1, use_bias=False),
        BatchNormalization(trainable=False),
        ReLU(),
        Conv2D(filters, kernel_size, padding='same'),
        BatchNormalization(trainable=False),
        ReLU(),
    ], name)

def build_separable_conv(filters, kernel_size, name=None):
    return Sequential([
        Conv2D(filters*3, kernel_size=1, use_bias=False),
        BatchNormalization(trainable=False),
        ReLU(),
        SeparableConv2D(filters, kernel_size, padding='same', use_bias=False),
        # Conv2D(filters, kernel_size=mini_enas1, use_bias=False),
        BatchNormalization(trainable=False),
        ReLU(),
    ], name)


def build_avg_pool(filters, name=None):
    return Sequential([
        Conv2D(filters, kernel_size=1, use_bias=False),
        BatchNormalization(trainable=False),
        ReLU(),
        AveragePooling2D(pool_size=3, strides=1, padding='same'),
        BatchNormalization(trainable=False),
    ], name)

def build_max_pool(filters, name=None):
    return Sequential([
        Conv2D(filters, kernel_size=1, use_bias=False),
        BatchNormalization(trainable=False),
        ReLU(),
        MaxPool2D(pool_size=3, strides=1, padding='same'),
        BatchNormalization(trainable=False),
    ], name)
    
def build_stem(filters):
    return Sequential([
            Conv2D(filters, kernel_size=3, padding='same', use_bias=False),
            BatchNormalization(trainable=False)
        ])    

def get_node_space(node_name_space,mini_enas=True):
    # print("in get_node_space")
    node_space=[]
    i=0
    for node in node_name_space:
        if node['type']=='conv':
            if mini_enas==False:
                print("normal conv")
                node_space.append(build_conv(node['filters'], node['kernel_size']))
                              # ,name=node['type']+'{}{}{}'.format(node['kernel_size'],'_',i)))
            
            else:
                print("sep conv")
                node_space.append(build_separable_conv(node['filters'], node['kernel_size']))
                              # ,name=node['type']+'{}'.format(node['kernel_size'])))
        elif node['type']=='avgpool':
            node_space.append(build_avg_pool(node['filters']))
            # node_space.append(build_avg_pool(node['filters'],name=node['type']))
        elif node['type']=='maxpool':
            node_space.append(build_avg_pool(node['filters']))
            # node_space.append(build_avg_pool(node['filters'],name=node['type']))
        else:
            raise ValueError('Unrecognized node')
        i+=1
    return node_space