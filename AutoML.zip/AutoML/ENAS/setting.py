project_name='ENAS'

bucket='public-data'

data_path={'cifar10':'enas-data/cifar10/',
           'cifar100':'enas-data/cifar100/',
           'mnist':'enas-data/mnist/',
           'fashion_mnist':'enas-data/fashion-mnist/'}
log_path='AutoML/ENAS/my_log/'
data_local_path='AutoML/ENAS/data/'
save_model_path='AutoML/ENAS/my_log/model/'