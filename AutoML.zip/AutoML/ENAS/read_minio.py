import minio
import os
import threading
import zipfile
import tarfile
import time
from AutoML.ENAS.setting import*
minio_conf = {
    'endpoint': '10.10.1.205:9000',
    'access_key': 'AKIAIOSFODNN7ETANGYI',
    'secret_key': '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',
    'secure': False
}



def bar_of_download(src_size, des_size):
    """
    下载进度显示条
    :param src_size: 源文件大小
    :param des_path: 目标文件的大小
    :return:
    """
    # bar_list = []
    # filePath = unicode(des_path, 'utf8')
    # fsize = os.path.getsize(des_path)
    # proportion_hundred = int(des_size/src_size)
    # proportion = int(des_size/src_size) # 只用这一个在训练的时候会失效，不能正常下载训练集
    proportion = 0
    proportion_hundred = 0
    # logger.info(src_size)
    if(src_size < 1024*1024):
        proportion = int(des_size / src_size)  # 只用这一个在训练的时候会失效，不能正常下载训练集
        # logger.info(proportion)
        proportion_hundred = int(proportion * 100)

    elif(src_size >= 1024*1024):
        fsize = int(des_size / float(1024 * 1024))  # 本地文件下载的大小MB级别
        src_size = int(src_size / int(1024 * 1024))  # 远程文件大小MB级别
        proportion = fsize / src_size
        # logger.info(proportion)
        proportion_hundred = int(proportion * 100)
    # proportion = int(proportion * 10)
    # logger.info(proportion_hundred)

    # fsize_mb =  round(fsize, 2)
    # src_size_mb = round(src_size,2)
    # star_num = "[{}]----{}%".format("#" * proportion_hundred,proportion_hundred)
    # star_num = "[{}]-{}%-已下载:{}MB/总计:{}MB".format("#" * proportion_hundred, proportion_hundred,fsize,src_size)
    # total_size = "总计:{}MB".format(src_size)
    star_num = "[{}]-{}%".format("▌" * proportion_hundred, proportion_hundred)
    # logger.info(star_num)
    return star_num # 这里接收tuple

def download_bar_look( src_size_local, des_path, my_thread):
    print(des_path)
    des_size = 0
    star_set = {"[]"}
    # 这里有安全隐患：用户的代码文件要是比较大的话可能会有问题
    try:
        print("downloading......")
        while not os.path.exists(des_path):
            time.sleep(0.5)
            print("waiting...")
        while my_thread.is_alive():
            time.sleep(0.5)  # 减少io的浪费
            # des_size = os.path.getsize(des_path)/float(1024*1024)
            # # 这里显示的进度条居然是负的，我也是服了
            # star_num = bar_of_download(src_size_local, des_size)
            # old_length = len(star_set)
            # star_set.add(star_num)
            # new_length = len(star_set)
            # print("hello world")
            # if (old_length is not new_length):
            #     # logger.info(star_num)
            #     print(star_num)
            #     old_length = new_length
    except Exception as e:
        print('显示进度条函数遇到的异常：', e)


def load_data_minio(bucket: str,name: str):
    client = minio.Minio(**minio_conf)
    data_set_files = client.list_objects(
                # mnist
                # bucket_name=bucket, prefix='jBwyBXCS7A/', recursive=True) 
                # bucket_name=bucket, prefix='Y6YqVzpqKz/', recursive=True) 
                # bucket_name=bucket, prefix='b3FvOeeATL-demo/', recursive=True) 
                bucket_name=bucket, prefix=data_path[name], recursive=True) 
                # bucket_name=bucket,  recursive=True)
    print('function:get_list_objects,data_set_files:',
                  type(data_set_files), data_set_files)
    file_paths = []
    for obj in data_set_files:
        print(obj.bucket_name, obj.object_name.encode('utf-8'),
                obj.last_modified, obj.etag, obj.size, obj.content_type)
        # b'4hCbN/mnist_vis.zip'====>4hCbN/mnist_vis.zip
        filepath = str(obj.object_name.encode('utf-8'))[2:-1]
        # filepath = filepath.split("/")[1]  #4hCbN/mnist_vis.zip===>mnist_vis.zip
        file_paths.append(filepath)
        user_file_size = obj.size
        dataset_size = obj.size
    # logger.info(file_paths)
    print('file_paths:', type(file_paths), file_paths)
    
    file_path = file_paths[0]

    file_name = file_path[file_path.rfind(r'/')+1:]
    print('当前准备下载的数据集的名称：', file_name)
    
    local_dataset_path=data_local_path
    public_bucket_name='public-data'
    local_zip_dataset_full_path = '{}{}'.format(
                local_dataset_path, file_name)
    local_unzip_dataset_full_path = '{}{}_dir'.format(
                local_dataset_path, file_name)  # 定位存储的相对位置
    print("数据集压缩包本地存储地址:{}".format(local_zip_dataset_full_path))
    print("数据集压缩包解压后本地存储地址:{}".format(
        local_zip_dataset_full_path))

    if os.path.exists(local_unzip_dataset_full_path):
        print("数据集地址:{}".format(local_unzip_dataset_full_path))
        print("数据集已存在,进入onMessage()")
        return local_unzip_dataset_full_path
    else:
        print("清空所有的损坏数据,递归删除文件夹")
        print(
            '===========================正在下载需要的数据集压缩包=================================')

        if not os.path.exists(local_zip_dataset_full_path):
            print("正在下载数据:{}".format(file_name))
            print('文件在服务器的位置：', file_path)
            t1 = threading.Thread(target=client.fget_object, args=(
                public_bucket_name, file_path, local_zip_dataset_full_path))
            t1.start()
            print("正在下载中...")
            src_size = dataset_size
            print('数据集总共的大小：', src_size)
            src_size_tmp = int(
                (src_size / int(1024 * 1024))*1000)/1000  # 远程文件大小MB级别
            total_size = "总计:{}MB".format(src_size_tmp)
            print(total_size)
            # download_bar_look(src_size, local_dataset_path, t1)
            download_bar_look(src_size, local_dataset_path,t1)
            print("已经成功下载到:{}".format(local_zip_dataset_full_path))
        else:
            print("数据集已存在:{}".format(local_zip_dataset_full_path))

        print("开始进行解压")  # 私有数据集每次运行完删除，但是公有的一直在本地,就可以先判定是否需要删除，在做决定
        # 默认压缩包类型为zip
        # 默认模式r,读
        name, name_endwith = os.path.splitext(file_name)
        temp_file_is_compressed_file_bool = True  # 用来判断下载下来的数据集是不是压缩文件的变量,默认是压缩文件
        print(name_endwith)
        try:
            if(name_endwith == ".zip"):
                # ['bb/', 'bb/aa.txt'] // 关闭io
                with zipfile.ZipFile(local_zip_dataset_full_path) as azip:
                    # 返回所有文件夹和文件
                    # 私有数据集每次运行完删除，但是公有的一直在本地,就可以先判定是否需要删除，在做决定
                    print("开始进行解压")

                # 抽取所有的文件
                    print("解压到文件夹{}".format(
                        local_unzip_dataset_full_path))
                    if not os.path.exists(local_unzip_dataset_full_path):
                        # 这里保留，还是这样吧，提取完就删除源文件夹，或者保留，可以保留
                        azip.extractall(
                            path=local_unzip_dataset_full_path)
                    # 这里使用标准的处理格式
                    print("解压结束")
            elif(name_endwith == ".tgz"):
                print("解压到文件夹{}".format(
                    local_unzip_dataset_full_path))
                with tarfile.open(local_zip_dataset_full_path, 'r:gz') as tar:
                    for tarinfo in tar:
                        tar.extract(
                            tarinfo.name, local_unzip_dataset_full_path)
                print("解压结束")
            else:
                temp_file_is_compressed_file_bool = False
                print('文件的格式是{}，并不是zip或者tgz，并不需要解压'.format(name_endwith))
        except Exception as e:
            print('解压文件报的错：', e)
    
    
    
    
    
    # if not client.bucket_exists(bucket):
    #     return None
    # data = client.get_object(bucket, 'test2')
    # path = "receive.zip"
    # with open(path, 'wb') as file_data:
    #     for d in data.stream(32 * 1024):
    #         file_data.write(d)
    # return data.data
    return("ok")

# print(load_data_minio("public-data"))
# print(type(load_data_minio("public_data")))
