from AutoML.ENAS.enas_manager import ENASManager
import AutoML.DARTS.train_search
#import AutoML.DARTS.train_eval
import os
pid = os.getpid()
print("pid:",pid)
import requests

url = 'http://10.10.1.210/api/v1/job/create'
data = {
'student_id': '1913188',
'password': '123456',
'description': 'mini enas',
'server_ip': '10.10.1.208',
'duration': '几天',
'pid': pid,
'server_user': 'yuchuanyue',
'command': 'python',
'use_gpu': 1,
}
r = requests.post(url, data=data)
print(r.text)
def AutoMLManager(mode,ds_train, ds_test,local_middle_save_path,train_instance_logger,train_instance_id,train_all_info):
    if mode=='darts':
        train_search.args.save = '{}search-{}-{}'.format(local_middle_save_path, args.note, time.strftime("%Y%m%d-%H%M%S"))
        search_for_cell(ds_train,ds_test) #先找cell
        #备用
        #search_for_cell(ds_train,ds_test,train_all_info.dataset_other_info['classNum'])
        #train_eval.args.save='{}eval-{}-{}'.format(local_middle_save_path, args.note, time.strftime("%Y%m%d-%H%M%S"))
        #search_for_arch(ds_train,ds_test,train_all_info.dataset_other_info['classNum'])
    elif mode=='enas':
        enas_manager=ENASManager()
        enas_manager.set_dataset(ds_train, ds_test)
        enas_manager.set_local_middle_save_path(local_middle_save_path)
        enas_manager.set_train_instance_logger(train_instance_logger)
        enas_manager.set_train_instance_id(train_instance_id)
        enas_manager.set_num_classes(train_all_info.dataset_other_info['classNum'])
        enas_manager.start_train()
        
        
        
# AutoMLManager('enas',"cifar10")
